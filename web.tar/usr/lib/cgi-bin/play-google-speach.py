#!/usr/bin/python3
from google.cloud import texttospeech
from logging import handlers
from logging.handlers import RotatingFileHandler
import argparse
import logging
import os
import re
import sys
import time

DEBUG = False

#setup logging
logger = logging.getLogger('')
logger.setLevel(logging.DEBUG)
format = logging.Formatter("%(asctime)s - %(name)s - %(levelname)s - %(message)s")
ch = logging.StreamHandler(sys.stdout)
ch.setFormatter(format)
logger.addHandler(ch)
logfile = "/tmp/play-google-speach.log"
fh = handlers.RotatingFileHandler(logfile, maxBytes=(1048576*5), backupCount=7)
fh.setFormatter(format)
logger.addHandler(fh)
logger.info("Starting play-google-speach.py")

# Initiate the command line parser
parser = argparse.ArgumentParser()
parser.add_argument("--sex", "-s", choices=['m','f'], help="Sex of the voice")
parser.add_argument(dest="message", help="The words it has to say")
args = parser.parse_args()

# Instantiates a Google TTS client
os.environ['GOOGLE_APPLICATION_CREDENTIALS'] = "/home/pi/joyce-2d487b74673d.json"
client = texttospeech.TextToSpeechClient()


def main():
    logging.info("The words it has to say are: " + args.message)

    # Name audio file
    import time
    timestr = time.strftime("%Y%m%d-%H%M%S")
    audiofile = "/tmp/" + timestr + "-" + slugify(args.message) + ".mp3"

    # Create the audio file
    line_to_audio(args.message, audiofile)

    # Play the announcement tune
    #logger.info("Playing tune: " + tune + "")
    #os.system("omxplayer --no-keys --no-osd " + tune)

    # Play the audio file
    logger.info("Playing audiofile: " + audiofile)
    os.system("play " + audiofile)

def line_to_audio(line, audiofile):
  # Set the text input to be synthesized
  ssml = line_to_ssml(line)
#      import pdb; pdb.set_trace()
  logger.info("SSML formatted line: " + ssml + "")
  logger.info("Going to SynthesisInput")
  synthesis_input = texttospeech.types.SynthesisInput(ssml=ssml)

  # Build the voice request, select the language code ("en-US") and the ssml
  # voice gender ("neutral")
  logger.info("Going to VoiceSelectionParams")
  voice = texttospeech.types.VoiceSelectionParams(
    language_code='nl-NL',
    name='nl-NL-Wavenet-C',
    ssml_gender=texttospeech.enums.SsmlVoiceGender.MALE)

  # Select the type of audio file you want returned
  logger.info("Going to AudioConfig")
  audio_config = texttospeech.types.AudioConfig(
    audio_encoding=texttospeech.enums.AudioEncoding.MP3,
    volume_gain_db=-1.0)

  # Perform the text-to-speech request on the text input with the selected
  # voice parameters and audio file type
  logger.info("Going to synthesize_speech")
  response = client.synthesize_speech(synthesis_input, voice, audio_config)

  # The response's audio_content is binary.
  logger.info("Going to write audio content to file")
  with open(audiofile, 'wb') as out:
    # Write the response to the output file.
    out.write(response.audio_content)
    print('Audio content written to file ' + audiofile)


#
# Generic functions
#


def line_to_ssml(s):
    from lxml import etree
    speak = etree.Element('speak')
    element = etree.Element('s')
    element.text = s
    speak.append(element)
    return etree.tostring(speak, encoding='unicode', method='xml')


def slugify(value):
  """
  Normalizes string, converts to lowercase, removes non-alpha characters
  (except dot, to  make sure the file extension is kept),
  and converts spaces to hyphens.
  """
  import unicodedata
  import re
  value = value
  value = unicodedata.normalize('NFKD', value)  # .encode('ascii', 'ignore')
  value = re.sub('[^\w\s.-]', '', value).strip().lower()
  value = re.sub('[-\s]+', '-', value)
  return value


if __name__ == '__main__':
    main()
